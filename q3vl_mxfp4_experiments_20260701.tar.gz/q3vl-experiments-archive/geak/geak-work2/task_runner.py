#!/usr/bin/env python3
"""GEAK harness for aiter's dynamic_mxfp4_quant — the Triton kernel vLLM's quark
MXFP4 path ACTUALLY calls on the served decode path (quark_ocp_mx.py:110).

Modes: compile | correctness | performance
- Editable source: ../kernel.py (copy of aiter _triton_kernels/quant/quant.py).
  GEAK edits it; we inject the edited @triton.jit kernels into installed aiter so the
  public wrapper dynamic_mxfp4_quant runs GEAK's version.
- Correctness: dequant kernel output, compare to torch mxfp4 reference (cos >= 0.99;
  mxfp4 is lossy but this is pure quant, so tolerance is tighter than the rms-fused case).
- Performance: median latency over served shapes, prints GEAK_RESULT_LATENCY_MS (sum, lower better).

Served shapes: N=4096 (hidden), M in decode buckets {1,8,16,32,64,128,256}.
"""
import os, sys, json, argparse, statistics, hashlib
REPO = os.environ.get("GEAK_WORK_DIR") or os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
os.environ.setdefault("HOME", "/tmp/hfhome")
# GEAK sanitizer contract: make aiter's JIT resolve per-worktree, not the baseline repo.
# (Harmless for our Triton-only injection but satisfies the sanitizer and isolates slots.)
os.environ.setdefault("AITER_META_DIR", "/opt/aiter")
_slot = os.environ.get("GEAK_GPU_ID", os.environ.get("HIP_VISIBLE_DEVICES", "0")).split(",")[0]
os.environ.setdefault("AITER_JIT_DIR", f"/tmp/aiter_jit_slot{_slot}")
if "/opt/aiter" not in sys.path:
    sys.path.insert(0, "/opt/aiter")
import torch


def _kernel_sha():
    return hashlib.sha256(open(os.path.join(REPO, "kernel.py"), "rb").read()).hexdigest()[:12]

N = 4096
M_BUCKETS = [1, 8, 16, 32, 64, 128, 256]
GROUP = 32


def _inject():
    import types
    import aiter.ops.triton._triton_kernels.quant.quant as inst
    src = open(os.path.join(REPO, "kernel.py")).read()
    mod = types.ModuleType("geak_dynquant")
    mod.__file__ = os.path.join(REPO, "kernel.py")
    exec(compile(src, os.path.join(REPO, "kernel.py"), "exec"), mod.__dict__)
    # Triton kernels may be wrapped as JITFunction, Heuristics, or Autotuner.
    _K = ("JITFunction", "Heuristics", "Autotuner")
    patched = []
    for name in dir(mod):
        obj = getattr(mod, name)
        if hasattr(inst, name) and any(k in str(type(obj)) for k in _K):
            setattr(inst, name, obj); patched.append(name)
    if not patched:
        raise RuntimeError("injector patched 0 kernels — GEAK edits would be a no-op")
    print(f"PATCH_PROOF kernel.py sha={_kernel_sha()} swapped_jit={len(patched)}", file=sys.stderr, flush=True)
    return patched


def run_compile():
    try:
        p = _inject()
        import ast; ast.parse(open(os.path.join(REPO, "kernel.py")).read())
        return True, f"patched_jit={p}"
    except Exception:
        import traceback; return False, traceback.format_exc()


def _mk(M):
    torch.manual_seed(7 + M)
    return torch.randn(M, N, device="cuda", dtype=torch.bfloat16)


def run_correctness():
    _inject()
    from aiter.ops.triton.quant.quant import dynamic_mxfp4_quant
    from aiter.utility.fp4_utils import mxfp4_to_f32, e8m0_to_f32
    bad = []
    for M in M_BUCKETS:
        x = _mk(M)
        x_fp4, bs = dynamic_mxfp4_quant(x)
        deq = mxfp4_to_f32(x_fp4).to(torch.float32).reshape(M, -1)
        scales = e8m0_to_f32(bs).to(torch.float32).reshape(M, -1)
        deq = (deq.reshape(M, -1, GROUP) * scales.unsqueeze(-1)).reshape(M, N)
        ref = x.to(torch.float32)
        cos = torch.nn.functional.cosine_similarity(deq, ref, dim=-1).mean().item()
        if cos < 0.99:
            bad.append((M, round(cos, 4)))
    ok = len(bad) == 0
    return ok, ("all cos>=0.99" if ok else f"low cos: {bad}")


def _time(fn, warmup=25, iters=100):
    for _ in range(warmup): fn()
    torch.cuda.synchronize()
    s = torch.cuda.Event(enable_timing=True); e = torch.cuda.Event(enable_timing=True)
    ts = []
    for _ in range(iters):
        s.record(); fn(); e.record(); torch.cuda.synchronize(); ts.append(s.elapsed_time(e))
    return statistics.median(ts)


def run_performance():
    _inject()
    from aiter.ops.triton.quant.quant import dynamic_mxfp4_quant
    cases, total = [], 0.0
    for M in M_BUCKETS:
        x = _mk(M)
        ms = _time(lambda: dynamic_mxfp4_quant(x))
        total += ms
        cases.append({"test_case_id": f"M{M}", "execution_time_ms": ms, "params": {"M": M, "N": N}})
    return cases, total


def main():
    p = argparse.ArgumentParser(); p.add_argument("mode", choices=["compile", "correctness", "performance"])
    a = p.parse_args(); bd = os.path.join(REPO, "build"); os.makedirs(bd, exist_ok=True)
    if a.mode == "compile":
        ok, err = run_compile(); json.dump({"ok": ok, "err": err}, open(f"{bd}/compile_report.json", "w"))
        print(f"Compilation: {'PASS' if ok else 'FAIL'}");
        if not ok: print(err); sys.exit(1)
    elif a.mode == "correctness":
        ok, err = run_correctness(); json.dump({"ok": ok, "err": err}, open(f"{bd}/correctness_report.json", "w"))
        print(f"Correctness: {'PASS' if ok else 'FAIL'} ({err})")
        if not ok: sys.exit(1)
    elif a.mode == "performance":
        cases, total = run_performance(); json.dump(cases, open(f"{bd}/performance_report.json", "w"))
        for c in cases: print(f"Perf: {c['execution_time_ms']:.6f} ms ({c['test_case_id']})")
        print(f"PATCH_PROOF kernel.py sha={_kernel_sha()}")
        print(f"GEAK_RESULT_LATENCY_MS={total:.6f}")
        print(f"GEAK_RESULT_KERNEL_MS={total:.6f}")


if __name__ == "__main__":
    main()
