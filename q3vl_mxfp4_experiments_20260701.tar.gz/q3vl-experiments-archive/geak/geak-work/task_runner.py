#!/usr/bin/env python3
"""GEAK harness for the aiter Triton fused_rms_mxfp4_quant kernel.

Modes: compile | correctness | performance
- The editable kernel source is ../kernel.py (a copy of aiter's
  _triton_kernels/quant/fused_mxfp4_quant.py). GEAK edits THAT file.
- We inject the repo's edited @triton.jit kernels into the installed aiter
  module so the public wrapper `fused_rms_mxfp4_quant` runs GEAK's version.
- Correctness is checked against a pure-torch reference (rmsnorm + mxfp4 quant).
- Performance times the public wrapper end-to-end and prints
  GEAK_RESULT_LATENCY_MS / GEAK_RESULT_KERNEL_MS markers.

Shapes target the served model: Qwen3-VL-235B text hidden_size = 4096,
decode token buckets at mc=32 (M in {32,64,128,256}).
"""
import os, sys, json, argparse, importlib, statistics
# ensure installed aiter is importable even when GEAK strips PYTHONPATH
if "/opt/aiter" not in sys.path:
    sys.path.insert(0, "/opt/aiter")
import torch

# GEAK runs this in an isolated git worktree and exports GEAK_WORK_DIR to it.
# Resolve the repo from that when present so we read/inject the PATCHED kernel.py.
REPO = os.environ.get("GEAK_WORK_DIR") or os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
os.environ.setdefault("HOME", "/tmp/hfhome")

HID = 4096
EPS = 1e-6
M_BUCKETS = [32, 64, 128, 256]
SCALE_GROUP = 32  # mxfp4 per_1x32


def _inject_kernels():
    """Load GEAK-edited jit kernels from REPO/kernel.py and patch them into
    the installed aiter _triton_kernels module so the wrapper uses them."""
    import aiter.ops.triton._triton_kernels.quant.fused_mxfp4_quant as inst
    sys.path.insert(0, REPO)
    import importlib.util, types
    src = open(os.path.join(REPO, "kernel.py")).read()
    # rewrite the package-relative import to its absolute aiter path so the
    # standalone copy loads outside its original package
    src = src.replace(
        "from .quant import _mxfp4_quant_op",
        "from aiter.ops.triton._triton_kernels.quant.quant import _mxfp4_quant_op",
    )
    mod = types.ModuleType("geak_kernel")
    mod.__file__ = os.path.join(REPO, "kernel.py")
    exec(compile(src, os.path.join(REPO, "kernel.py"), "exec"), mod.__dict__)
    patched = []
    for name in dir(mod):
        obj = getattr(mod, name)
        # triton JITFunction objects + the helper @triton.jit ops
        if hasattr(inst, name) and (str(type(obj)).find("JITFunction") >= 0 or name.startswith("_fused") or name == "_rmsmorm_op"):
            setattr(inst, name, obj)
            patched.append(name)
    return patched


def _ref_rmsnorm_mxfp4(x, w, eps):
    xf = x.to(torch.float32)
    rn = torch.rsqrt(xf.pow(2).mean(-1, keepdim=True) + eps)
    return (xf * rn * w.to(torch.float32)).to(torch.bfloat16)


def run_compile():
    try:
        patched = _inject_kernels()
        import ast
        ast.parse(open(os.path.join(REPO, "kernel.py")).read())
        return True, f"patched={patched}"
    except Exception as e:
        import traceback
        return False, traceback.format_exc()


def _make_inputs(M):
    torch.manual_seed(1234 + M)
    x = torch.randn(M, HID, device="cuda", dtype=torch.bfloat16)
    w = torch.randn(HID, device="cuda", dtype=torch.bfloat16)
    return x, w


def run_correctness():
    _inject_kernels()
    from aiter.ops.triton.quant.fused_mxfp4_quant import fused_rms_mxfp4_quant
    from aiter.utility.fp4_utils import mxfp4_to_f32, e8m0_to_f32
    bad = []
    for M in M_BUCKETS:
        x, w = _make_inputs(M)
        (out_fp4, out_bs), out1, out2, _ = fused_rms_mxfp4_quant(
            x, w, EPS, output_unquantized_inp1=True)
        # dequant kernel output and compare to torch rms reference
        deq = mxfp4_to_f32(out_fp4).to(torch.float32).reshape(M, -1)
        scales = e8m0_to_f32(out_bs).to(torch.float32).reshape(M, -1)
        deq = (deq.reshape(M, -1, SCALE_GROUP) * scales.unsqueeze(-1)).reshape(M, HID)
        ref = _ref_rmsnorm_mxfp4(x, w, EPS).to(torch.float32)
        # cosine similarity per row (mxfp4 is lossy; gate on cos, like the repo)
        cos = torch.nn.functional.cosine_similarity(deq, ref, dim=-1).mean().item()
        if cos < 0.97:
            bad.append((M, cos))
    ok = len(bad) == 0
    return ok, ("all cos>=0.97" if ok else f"low cos: {bad}")


def _time(fn, warmup=25, iters=100):
    for _ in range(warmup):
        fn()
    torch.cuda.synchronize()
    # wall via events
    s = torch.cuda.Event(enable_timing=True); e = torch.cuda.Event(enable_timing=True)
    ts = []
    for _ in range(iters):
        s.record(); fn(); e.record(); torch.cuda.synchronize()
        ts.append(s.elapsed_time(e))
    return statistics.median(ts)


def run_performance():
    _inject_kernels()
    from aiter.ops.triton.quant.fused_mxfp4_quant import fused_rms_mxfp4_quant
    cases = []
    total = 0.0
    for M in M_BUCKETS:
        x, w = _make_inputs(M)
        fn = lambda: fused_rms_mxfp4_quant(x, w, EPS)
        ms = _time(fn)
        total += ms
        cases.append({"test_case_id": f"M{M}", "execution_time_ms": ms, "params": {"M": M, "N": HID}})
    return cases, total


def main():
    p = argparse.ArgumentParser()
    p.add_argument("mode", choices=["compile", "correctness", "performance"])
    a = p.parse_args()
    bd = os.path.join(REPO, "build"); os.makedirs(bd, exist_ok=True)

    if a.mode == "compile":
        ok, err = run_compile()
        json.dump({"ok": ok, "err": err}, open(os.path.join(bd, "compile_report.json"), "w"))
        print(f"Compilation: {'PASS' if ok else 'FAIL'}")
        if not ok: print(err); sys.exit(1)

    elif a.mode == "correctness":
        ok, err = run_correctness()
        json.dump({"ok": ok, "err": err}, open(os.path.join(bd, "correctness_report.json"), "w"))
        print(f"Correctness: {'PASS' if ok else 'FAIL'} ({err})")
        if not ok: sys.exit(1)

    elif a.mode == "performance":
        cases, total = run_performance()
        json.dump(cases, open(os.path.join(bd, "performance_report.json"), "w"))
        for c in cases:
            print(f"Perf: {c['execution_time_ms']:.5f} ms ({c['test_case_id']})")
        # GEAK scoring markers: sum over buckets (lower is better)
        print(f"GEAK_RESULT_LATENCY_MS={total:.5f}")
        print(f"GEAK_RESULT_KERNEL_MS={total:.5f}")


if __name__ == "__main__":
    main()
