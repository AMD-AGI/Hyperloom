# Q3VL MXFP4 TP1 — Experiment Archive
**Date:** 2026-07-01 | **Node:** MI355X (gfx950) | **Stack:** vLLM a65093c + aiter patch 0006

## What's in here

### docs/
- `q3vl_mxfp4_results.md` — Full experiment log, Addenda 1–6 (all results from both sessions)
- `q3vl_mxfp4_offline_uplift_plan.md` — Roofline-based uplift plan (July 2026, primary reference)
- `q3vl_mxfp4_uplift_plan.md` — Earlier mc=32-based plan (superseded but kept for history)

### profiler/
- `saturation_torch_profiler_out.txt` — **Key profile**: torch profiler text output at offline saturation
  (800 samples, max_throughput, real Shopify 8K dataset, ~840 concurrent reqs, KV 98%)
- `rocprofv3_mc32_decode/` — rocprofv3 kernel stats from decode-dominated mc=32 run (CSV)
- `rocprofv3_mc32_prefill/` — rocprofv3 kernel stats from prefill-dominated run (CSV)

> **NOTE:** The raw torch profiler trace file
> (`dp0_pp0_tp0_dcp0_ep0_rank0.*.pt.trace.json.gz`, **422 MB**) and the raw rocprofv3
> kernel_trace CSVs (~440 MB total) are **not included** due to size.
> They live on the node at:
> - `/tmp/off-gpu1-prof/outputs/profiled/traces/*.pt.trace.json.gz`
> - `/tmp/q3vl-run/rocprof_dec/.../44371_kernel_trace.csv`
> - `/tmp/q3vl-run/rocprof_out/.../28463_kernel_trace.csv`
> Open with `torch.profiler` Chrome trace viewer or `rocprofv3 --analyze`.

### geak/
Two GEAK (GPU Efficiency Advancement Kit) runs targeting different kernels:
- `geak-work/` — Target: `fused_rms_mxfp4_quant` (Triton). **Result: +8.2% kernel speedup (1.082×)**
  but kernel is not on the actual served decode path → 0% e2e gain.
- `geak-work2/` — Target: `dynamic_mxfp4_quant` (Triton). **Result: +0.9% kernel speedup (1.009×)**
  kernel is on path but too small → 0% e2e gain.
- Each contains: `original_kernel.py`, `optimized_kernel.py`, `task_runner.py`, `final_report.json`,
  per-round evaluation JSONs, and the winning diff patch.

### scripts/
- `serve_tp1.sh` — Launch vLLM with exact ml-perf tp1_mxfp4 knobs (GPU PORT EXTRA_ENV SILU args)
- `bench.sh` / `bench_offline.sh` — vllm bench serve clients (mc=32 synthetic / saturation)
- `run_geak.sh` / `run_geak2.sh` — GEAK run scripts
- `flydsl_tile_bench4.py` — FlyDSL tile sweep harness (correctness-filtered, atomic stage2 only)
- `flydsl_small_token_bench.py` — Small-token tile sweep for decode regime

### configs/
- `q3vl-tuned-fmoe-final.csv` — Correctness-validated flydsl tuned fmoe config
  (only token=4096 override; not dispatched in real serving — included for reference)
- `q3vl-tuned-fmoe.csv` — Earlier version with broader entries

### bench_results/
#### synthetic_mc32/  (vllm bench serve, mc=32, isl=1024, osl=150)
JSON outputs from the config sweep that found +3.1% gain from fusion_shared_experts+silu_and_mul.
These gains do NOT transfer to the real ml-perf workload.

#### offline_pipeline/  (benchmark.py, Shopify 8K, 4000 samples, max_throughput)
`result_summary.json` from all real ml-perf offline runs:
- `baseline` — 9.22 QPS (confirmed; matches tracker 9.20)
- `profiled_800` — 800-sample profiled run (lower QPS due to profiler overhead)
- `sweep_[A-G]` — 7 env/scheduler sweeps (all flat or regressive)
- `tuned_flydsl_final` — 9.17 QPS (FlyDSL tuned config, no improvement; token tier mismatch)
- `fresh_base_comparison` — 9.06–9.21 QPS (run-to-run variance baseline)

#### server_online/  (benchmark.py, poisson target_qps=5, 1500 samples)
- `server_baseline` — 4.91 QPS, e2e p99 = 13.06s
- `server_wins` — 4.91 QPS, e2e p99 = **17.74s** ← wins config regressed server SLA

### logs/
Full benchmark.py and vLLM server logs for each run.
- `mc32_sweep/` — mc=32 synthetic sweep logs (rounds 1–2, env sweep, GEAK rebench)
- `offline_pipeline/` — All real benchmark.py offline run logs
- `server_online/` — Server mode comparison logs
- `flydsl/` — FlyDSL tile sweep output logs

## Key numbers
| Workload | Baseline | Best achieved | Method |
|---|---|---|---|
| Offline (real, 4000 samples) | **9.22 QPS** | 9.22 QPS | — (optimal) |
| Server (poisson p99 SLA ≤12s) | 13.06s p99 | 13.06s p99 | — |
| mc=32 synthetic | 6.43 req/s | 6.62 req/s (+2.9%) | fusion_shared_experts (DON'T LAND: hurts real workloads) |
| GEAK fused_rms kernel | — | 1.082× kernel | Not on served path |
| GEAK dynamic_mxfp4 kernel | — | 1.009× kernel | On path but too small |
| FlyDSL tile sweep | 2.22ms stage1 | best correct=2.22ms | Heuristic already optimal at token=32768 |
