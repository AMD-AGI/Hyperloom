#!/usr/bin/env bash
# Offline max-throughput bench (saturate GPU). Args: PORT TAG NUM_PROMPTS
PORT=$1; TAG=$2; NP=${3:-2000}
MODEL=/tmp/q3vl-mxfp4
export HOME=/tmp/hfhome HF_HOME=/tmp/hf_cache
vllm bench serve \
  --backend openai-chat --endpoint /v1/chat/completions \
  --base-url "http://localhost:${PORT}" --model "$MODEL" \
  --dataset-name random-mm \
  --random-input-len 1024 --random-output-len 150 \
  --random-mm-base-items-per-request 1 \
  --random-mm-limit-mm-per-prompt '{"image":1,"video":0}' \
  --random-mm-bucket-config '{(512,512,1):1.0}' \
  --num-prompts "$NP" --num-warmups 32 \
  --max-concurrency 2048 \
  --ignore-eos --seed 5678 \
  --save-result --result-dir /tmp/q3vl-run/ --result-filename "${TAG}.json" \
  --trust-remote-code
