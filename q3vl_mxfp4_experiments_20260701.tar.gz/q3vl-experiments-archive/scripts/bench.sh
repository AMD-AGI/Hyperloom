#!/usr/bin/env bash
# Run MM benchmark client against a running server.
# Args: PORT TAG  [CONC ISL OSL NUM_PROMPTS]
set -x
PORT=${1:?port}; TAG=${2:?tag}
CONC=${3:-32}; ISL=${4:-1024}; OSL=${5:-150}
NUM_PROMPTS=${6:-$(( CONC * 10 ))}
NUM_WARMUPS=$(( CONC < 8 ? CONC : 8 ))
MODEL=/tmp/q3vl-mxfp4
OUT=/tmp/q3vl-run
export HOME=/tmp/hfhome HF_HOME=/tmp/hf_cache
vllm bench serve \
  --backend openai-chat \
  --endpoint /v1/chat/completions \
  --base-url "http://localhost:${PORT}" \
  --model "$MODEL" \
  --dataset-name random-mm \
  --random-input-len "$ISL" \
  --random-output-len "$OSL" \
  --random-mm-base-items-per-request 1 \
  --random-mm-limit-mm-per-prompt '{"image": 1, "video": 0}' \
  --random-mm-bucket-config '{(512, 512, 1): 1.0}' \
  --num-prompts "$NUM_PROMPTS" \
  --num-warmups "$NUM_WARMUPS" \
  --max-concurrency "$CONC" \
  --ignore-eos \
  --seed 5678 \
  --save-result \
  --result-dir "${OUT}/" \
  --result-filename "${TAG}.json" \
  --trust-remote-code
