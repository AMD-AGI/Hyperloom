#!/usr/bin/env python3
"""
FlyDSL tile sweep for Q3VL MXFP4 offline saturation.
Passes BF16 hidden_states (same as vLLM) with quant_type=per_1x32 — fused_moe does quant internally.

Model: E=128, topk=8, hidden=4096, inter=1536 (Qwen3-VL-235B)
Saturation token tiers: 4096, 8192, 16384  (matches fused_moe.py ≥4096 tier → t64x128x256_w4)

Run: ROCR_VISIBLE_DEVICES=3 HIP_VISIBLE_DEVICES=0 AITER_ONLINE_TUNE=0 python3 /tmp/flydsl_tile_bench4.py
"""
import os, sys, statistics, itertools, functools
os.environ.setdefault("HOME", "/tmp/hfhome")
os.environ["AITER_ONLINE_TUNE"] = "0"
os.environ["AITER_FLYDSL_FORCE"] = "1"
gpu = os.environ.get("ROCR_VISIBLE_DEVICES", "3").split(",")[0]
os.environ.setdefault("HIP_VISIBLE_DEVICES", "0")
os.environ.setdefault("AITER_JIT_DIR", f"/tmp/aiter_jit_slot{gpu}")
sys.path.insert(0, "/opt/aiter")

import torch, aiter
import aiter.fused_moe as fm
from aiter import dtypes, QuantType, ActivationType
from aiter.fused_moe import fused_topk
from aiter.ops.flydsl.moe_kernels import flydsl_kernel_name, get_flydsl_kernel_params

EXPERT = 128
TOPK   = 8
HIDDEN = 4096
INTER  = 1536
DTYPE  = torch.bfloat16

torch.set_default_device("cuda")
torch_quant = aiter.get_torch_quant(QuantType.per_1x32)


def make_data(token):
    torch.manual_seed(0)
    # hidden_states: BF16 (vLLM passes BF16; fused_moe does dynamic quant internally)
    hidden = torch.randn((token, HIDDEN), dtype=DTYPE) / 10
    # weights: preshuffled fp4x2 [E, INTER*2 // 2, HIDDEN // 2] and [E, HIDDEN // 2, INTER // 2]
    w1_raw = torch.randn((EXPERT, INTER*2, HIDDEN), dtype=DTYPE) / 10
    w2_raw = torch.randn((EXPERT, HIDDEN, INTER),   dtype=DTYPE) / 10
    w1_qt, w1_scale = torch_quant(w1_raw, quant_dtype=dtypes.fp4x2)
    w2_qt, w2_scale = torch_quant(w2_raw, quant_dtype=dtypes.fp4x2)
    w1_qt = w1_qt.view(EXPERT, INTER*2, HIDDEN//2)
    w2_qt = w2_qt.view(EXPERT, HIDDEN,  INTER//2)
    score = torch.randn((token, EXPERT), dtype=DTYPE)
    topk_w, topk_ids = fused_topk(hidden, score, TOPK, True)
    return hidden, w1_qt, w2_qt, topk_w, topk_ids, w1_scale, w2_scale


def run_fused(data):
    h, w1, w2, tw, ti, w1s, w2s = data
    return fm.fused_moe(
        h, w1, w2, tw, ti,
        quant_type=QuantType.per_1x32,
        w1_scale=w1s,
        w2_scale=w2s,
    )


def timed(fn, warmup=10, iters=40):
    for _ in range(warmup):
        fn()
    torch.cuda.synchronize()
    s = torch.cuda.Event(enable_timing=True)
    e = torch.cuda.Event(enable_timing=True)
    ts = []
    for _ in range(iters):
        s.record(); fn(); e.record()
        torch.cuda.synchronize()
        ts.append(s.elapsed_time(e))
    return statistics.median(ts)


def force_kernel(kn1, kn2, tile_m):
    """Monkey-patch get_2stage_cfgs to return a specific flydsl kernel pair."""
    orig = fm.get_2stage_cfgs

    @functools.lru_cache(maxsize=2048)
    def forced(token, model_dim, inter_dim, expert, topk,
                dtype, q_dtype_a, q_dtype_w, q_type, use_g1u1,
                activation, doweight_stage1, hidden_pad, intermediate_pad,
                is_shuffled, gate_mode, is_ep=False):
        enable_bias = fm._needs_swiglu_bias_support(dtype, q_type)
        return fm.MOEMetadata(
            functools.partial(fm._flydsl_stage1_wrapper,
                              kernelName=kn1, activation=activation,
                              inter_dim_pad=0, model_dim_pad=0),
            functools.partial(fm._flydsl_stage2_wrapper,
                              kernelName=kn2, inter_dim_pad=0, model_dim_pad=0),
            tile_m, -1, False,
            has_bias=enable_bias, fuse_quant="fp4", stage2_has_bias=enable_bias,
        )

    fm.get_2stage_cfgs = forced
    return orig


def restore(orig):
    fm.get_2stage_cfgs = orig


def bench_pair(token, kn1, kn2, tile_m, warmup=10, iters=40):
    if get_flydsl_kernel_params(kn1) is None:
        return None, "kn1 missing"
    if get_flydsl_kernel_params(kn2) is None:
        return None, "kn2 missing"
    data = make_data(token)
    orig = force_kernel(kn1, kn2, tile_m)
    try:
        for _ in range(warmup):
            run_fused(data)
        torch.cuda.synchronize()
        ms = timed(lambda: run_fused(data), warmup=0, iters=iters)
        return ms, None
    except Exception as ex:
        return None, str(ex)[:120]
    finally:
        restore(orig)


def get_heuristic_kn(token):
    """What the heuristic picks for this token count."""
    a_t = "fp4"
    if token < 2048:
        tm, sfx = 32, "w2"
    elif token < 4096:
        tm, sfx = 64, "w3_bnt0"
    elif token < 16384:
        tm, sfx = 64, "w4_bnt0"
    else:
        tm, sfx = 64, "w4_bnt0"
    base1 = flydsl_kernel_name(1, a_t, "fp4", "bf16", tm, 128, 256)
    raw1  = f"{base1}_{sfx}"
    kn1 = f"{raw1}_fp4" if get_flydsl_kernel_params(f"{raw1}_fp4") else raw1
    base2 = flydsl_kernel_name(2, a_t, "fp4", "bf16", tm, 128, 256, "atomic")
    kn2   = base2
    return kn1, kn2, tm


def main():
    token_tiers = [4096, 8192, 16384]

    # Build stage1 candidates
    stage1_cands = []
    for tm1 in [32, 64, 128]:
        suffixes = (["w2", "w3"] if tm1 == 32 else
                    ["w2_bnt0", "w3_bnt0", "w4_bnt0"] if tm1 == 64 else
                    ["w2_bnt0", "w3_bnt0"])
        for sfx in suffixes:
            for tn1 in [64, 128]:
                if tm1 == 32 and tn1 == 64:
                    continue  # not in registry for fp4_a
                base = flydsl_kernel_name(1, "fp4", "fp4", "bf16", tm1, tn1, 256)
                raw  = f"{base}_{sfx}"
                fused = f"{raw}_fp4"
                kn1 = fused if get_flydsl_kernel_params(fused) else raw
                if get_flydsl_kernel_params(kn1):
                    stage1_cands.append((tm1, kn1))

    # Deduplicate
    seen = set()
    stage1_cands = [x for x in stage1_cands if not (x in seen or seen.add(x))]

    # Build stage2 candidates
    stage2_cands = []
    for tm2 in [32, 64, 128]:
        for tn2 in [128, 256]:
            for tk2 in [128, 256]:
                for mode in ["atomic", "reduce"]:
                    kn2 = flydsl_kernel_name(2, "fp4", "fp4", "bf16", tm2, tn2, tk2, mode)
                    if get_flydsl_kernel_params(kn2):
                        stage2_cands.append((tm2, kn2))

    print(f"Stage1 candidates: {len(stage1_cands)}, Stage2 candidates: {len(stage2_cands)}")
    print(f"Total pairs: {len(stage1_cands)*len(stage2_cands)} × {len(token_tiers)} tiers\n")

    # Baseline (heuristic) for each tier
    print("=== HEURISTIC BASELINE ===")
    baselines = {}
    for token in token_tiers:
        kn1h, kn2h, tmh = get_heuristic_kn(token)
        print(f"token={token}: kn1={kn1h}")
        print(f"              kn2={kn2h}")
        ms, err = bench_pair(token, kn1h, kn2h, tmh, warmup=12, iters=50)
        if ms:
            print(f"              baseline = {ms:.4f} ms")
        else:
            print(f"              ERROR: {err}")
        baselines[token] = ms
        print()

    results = {t: None for t in token_tiers}

    for token in token_tiers:
        base = baselines[token]
        print(f"\n{'─'*130}")
        print(f"token = {token}  (heuristic baseline = {f'{base:.4f}' if base else 'ERR'} ms)")
        print(f"{'stage1 kernel':>65} {'stage2 kernel':>55} {'ms':>8} {'vs base':>8}")
        print(f"{'─'*130}")
        best_ms = None

        for (tm1, kn1), (tm2, kn2) in itertools.product(stage1_cands, stage2_cands):
            ms, err = bench_pair(token, kn1, kn2, tm1)
            if ms is not None:
                vs = f"{(base - ms) / base * 100:+.1f}%" if base else "?"
                tag = " ← BEST" if (best_ms is None or ms < best_ms) else ""
                print(f"{kn1:>65} {kn2:>55} {ms:>8.4f} {vs:>8}{tag}")
                if best_ms is None or ms < best_ms:
                    best_ms = ms
                    results[token] = (kn1, kn2, tm1, ms)
            else:
                print(f"{kn1:>65} {kn2:>55} {'ERR':>8} {err}")

    print("\n\n=== FINAL WINNERS ===")
    for token, row in results.items():
        base = baselines[token]
        if row:
            kn1, kn2, tile_m, ms = row
            vs = f"{(base - ms) / base * 100:+.1f}%" if base else "?"
            print(f"token={token}: {ms:.4f}ms vs {base:.4f}ms heuristic = {vs}  tile_m={tile_m}")
            print(f"  kn1={kn1}")
            print(f"  kn2={kn2}")

    print("\n=== TUNED FMOE CSV ROWS ===")
    hdr = "cu_num,token,model_dim,inter_dim,expert,topk,act_type,dtype,q_dtype_a,q_dtype_w,q_type,use_g1u1,doweight_stage1,block_m,ksplit,us1,kernelName1,err1,us2,kernelName2,err2,us,run_1stage,xbf16,flat,tflops,bw,_tag"
    print(hdr)
    for token, row in results.items():
        if row is None:
            continue
        kn1, kn2, tile_m, ms = row
        print(f"256,{token},{HIDDEN},{INTER},{EXPERT},{TOPK},"
              f"ActivationType.Silu,torch.bfloat16,torch.float4_e2m1fn_x2,torch.float4_e2m1fn_x2,"
              f"QuantType.per_1x32,1,0,{tile_m},0,"
              f"0.0,{kn1},0.0,0.0,{kn2},0.0,{ms:.4f},0,0,0,0,0,q3vl_offline_tuned")


if __name__ == "__main__":
    main()
