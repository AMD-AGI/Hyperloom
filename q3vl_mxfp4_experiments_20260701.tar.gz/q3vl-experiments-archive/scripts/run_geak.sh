#!/usr/bin/env bash
set -x
export HOME=/tmp/hfhome
export PYTHONUSERBASE=/tmp/geak-py
export PATH=/tmp/geak-py/bin:$PATH
export PYTHONPATH=/opt/aiter
export AMD_LLM_API_KEY="$(echo "$ANTHROPIC_CUSTOM_HEADERS" | sed -E 's/.*Ocp-Apim-Subscription-Key:[[:space:]]*//')"
export GEAK_USER="vassavas@amd.com"
export GEAK_DEFAULT_MODEL="claude-opus-4.8"
export GEAK_MODEL_NAME="claude-opus-4.8"
# point GEAK's amd_claude at our local tunnel
export GEAK_BASE_URL="$ANTHROPIC_BASE_URL"
export GEAK_ANTHROPIC_BASE_URL="$ANTHROPIC_BASE_URL"
export ROCR_VISIBLE_DEVICES=0,1,2,3
export TOKENIZERS_PARALLELISM=false

REPO=/tmp/geak-work/mxfp4_quant
TESTCMD="python3 scripts/task_runner.py compile && python3 scripts/task_runner.py correctness && python3 scripts/task_runner.py performance"

geak --config /tmp/geak-work/geak_local.yaml \
  --repo "$REPO" \
  --kernel-url "$REPO/kernel.py" \
  --test-command "$TESTCMD" \
  --task /tmp/geak-work/task.txt \
  --num-parallel 4 \
  --gpu-ids 0,1,2,3 \
  --mode full \
  --target kernel \
  --debug \
  --yolo \
  -o /tmp/geak-work/geak_run 2>&1
