#!/usr/bin/env python3
"""Small-token tile sweep for decode-heavy regimes (token=512, 1024, 2048)."""
import os, sys, statistics, itertools, functools
os.environ.setdefault("HOME", "/tmp/hfhome")
os.environ["AITER_ONLINE_TUNE"] = "0"
os.environ["AITER_FLYDSL_FORCE"] = "1"
gpu = os.environ.get("ROCR_VISIBLE_DEVICES", "4").split(",")[0]
os.environ.setdefault("HIP_VISIBLE_DEVICES", "0")
os.environ.setdefault("AITER_JIT_DIR", f"/tmp/aiter_jit_slot{gpu}")
sys.path.insert(0, "/opt/aiter")

import torch, aiter
import aiter.fused_moe as fm
from aiter import dtypes, QuantType, ActivationType
from aiter.fused_moe import fused_topk
from aiter.ops.flydsl.moe_kernels import flydsl_kernel_name, get_flydsl_kernel_params

EXPERT = 128; TOPK = 8; HIDDEN = 4096; INTER = 1536; DTYPE = torch.bfloat16
torch.set_default_device("cuda")
torch_quant = aiter.get_torch_quant(QuantType.per_1x32)

def make_data(token):
    torch.manual_seed(0)
    h = torch.randn((token, HIDDEN), dtype=DTYPE) / 10
    w1_raw = torch.randn((EXPERT, INTER*2, HIDDEN), dtype=DTYPE) / 10
    w2_raw = torch.randn((EXPERT, HIDDEN, INTER), dtype=DTYPE) / 10
    w1_qt, w1_scale = torch_quant(w1_raw, quant_dtype=dtypes.fp4x2)
    w2_qt, w2_scale = torch_quant(w2_raw, quant_dtype=dtypes.fp4x2)
    w1_qt = w1_qt.view(EXPERT, INTER*2, HIDDEN//2)
    w2_qt = w2_qt.view(EXPERT, HIDDEN, INTER//2)
    score = torch.randn((token, EXPERT), dtype=DTYPE)
    tw, ti = fused_topk(h, score, TOPK, True)
    return h, w1_qt, w2_qt, tw, ti, w1_scale, w2_scale

def run_fused(data):
    h, w1, w2, tw, ti, w1s, w2s = data
    return fm.fused_moe(h, w1, w2, tw, ti, quant_type=QuantType.per_1x32, w1_scale=w1s, w2_scale=w2s)

def timed(fn, warmup=10, iters=50):
    for _ in range(warmup): fn()
    torch.cuda.synchronize()
    s = torch.cuda.Event(enable_timing=True); e = torch.cuda.Event(enable_timing=True)
    ts = []
    for _ in range(iters): s.record(); fn(); e.record(); torch.cuda.synchronize(); ts.append(s.elapsed_time(e))
    return statistics.median(ts)

def force_kernel(kn1, kn2, tile_m):
    orig = fm.get_2stage_cfgs
    @functools.lru_cache(maxsize=2048)
    def forced(token, model_dim, inter_dim, expert, topk, dtype, q_dtype_a, q_dtype_w,
                q_type, use_g1u1, activation, doweight_stage1, hidden_pad, intermediate_pad,
                is_shuffled, gate_mode, is_ep=False):
        enable_bias = fm._needs_swiglu_bias_support(dtype, q_type)
        return fm.MOEMetadata(
            functools.partial(fm._flydsl_stage1_wrapper, kernelName=kn1, activation=activation, inter_dim_pad=0, model_dim_pad=0),
            functools.partial(fm._flydsl_stage2_wrapper, kernelName=kn2, inter_dim_pad=0, model_dim_pad=0),
            tile_m, -1, False, has_bias=enable_bias, fuse_quant="fp4", stage2_has_bias=enable_bias)
    fm.get_2stage_cfgs = forced
    return orig

def restore(orig): fm.get_2stage_cfgs = orig

def bench_pair(token, kn1, kn2, tile_m):
    if get_flydsl_kernel_params(kn1) is None: return None, "kn1"
    if get_flydsl_kernel_params(kn2) is None: return None, "kn2"
    data = make_data(token)
    orig = force_kernel(kn1, kn2, tile_m)
    try:
        ms = timed(lambda: run_fused(data))
        return ms, None
    except Exception as ex: return None, str(ex)[:80]
    finally: restore(orig)

token_tiers = [512, 1024, 2048]
stage1_cands = []
for tm1 in [16, 32, 64]:
    for sfx in (["w2","w3"] if tm1 <= 32 else ["w2_bnt0","w3_bnt0","w4_bnt0"]):
        base = flydsl_kernel_name(1, "fp4", "fp4", "bf16", tm1, 128, 256)
        raw = f"{base}_{sfx}"; fused = f"{raw}_fp4"
        kn1 = fused if get_flydsl_kernel_params(fused) else raw
        if get_flydsl_kernel_params(kn1): stage1_cands.append((tm1, kn1))

stage2_cands = [(tm2, flydsl_kernel_name(2, "fp4", "fp4", "bf16", tm2, tn2, tk2, mode))
    for tm2,tn2,tk2,mode in itertools.product([16,32,64],[128,256],[128,256],["atomic","reduce"])
    if get_flydsl_kernel_params(flydsl_kernel_name(2,"fp4","fp4","bf16",tm2,tn2,tk2,mode))]

print(f"Stage1: {len(stage1_cands)}, Stage2: {len(stage2_cands)}, Tokens: {token_tiers}")

results = {}
for token in token_tiers:
    best_ms = None; best_row = None
    data0 = make_data(token)
    base_ms = timed(lambda: run_fused(data0))
    print(f"\ntoken={token}: baseline={base_ms:.4f}ms")
    for (tm1, kn1), (tm2, kn2) in itertools.product(stage1_cands, stage2_cands):
        ms, err = bench_pair(token, kn1, kn2, tm1)
        if ms is not None:
            vs = f"{(base_ms-ms)/base_ms*100:+.1f}%"
            tag = " BEST" if (best_ms is None or ms < best_ms) else ""
            print(f"  {kn1[-40:]:>40} {kn2[-40:]:>40} {ms:.4f} {vs}{tag}")
            if best_ms is None or ms < best_ms: best_ms=ms; best_row=(kn1,kn2,tm1,ms)
        else: print(f"  {kn1[-40:]:>40} {kn2[-40:]:>40} ERR {err}")
    results[token] = (best_row, base_ms)

print("\n=== WINNERS ===")
print("cu_num,token,model_dim,inter_dim,expert,topk,act_type,dtype,q_dtype_a,q_dtype_w,q_type,use_g1u1,doweight_stage1,block_m,ksplit,us1,kernelName1,err1,us2,kernelName2,err2,us,run_1stage,xbf16,flat,tflops,bw,_tag")
for token, (row, base) in results.items():
    if row:
        kn1,kn2,tile_m,ms = row
        print(f"token={token}: {ms:.4f}ms vs {base:.4f}ms = {(base-ms)/base*100:+.1f}%")
        print(f"256,{token},{HIDDEN},{INTER},{EXPERT},{TOPK},ActivationType.Silu,torch.bfloat16,torch.float4_e2m1fn_x2,torch.float4_e2m1fn_x2,QuantType.per_1x32,1,0,{tile_m},0,0.0,{kn1},0.0,0.0,{kn2},0.0,{ms:.4f},0,0,0,0,0,")
