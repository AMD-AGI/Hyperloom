#!/usr/bin/env bash
set -x
export HOME=/tmp/hfhome PYTHONUSERBASE=/tmp/geak-py PATH=/tmp/geak-py/bin:$PATH PYTHONPATH=/opt/aiter
export AMD_LLM_API_KEY="$(echo "$ANTHROPIC_CUSTOM_HEADERS" | sed -E 's/.*Ocp-Apim-Subscription-Key:[[:space:]]*//')"
export GEAK_USER="vassavas@amd.com" GEAK_DEFAULT_MODEL="claude-opus-4.8" GEAK_MODEL_NAME="claude-opus-4.8"
export GEAK_BASE_URL="$ANTHROPIC_BASE_URL" GEAK_ANTHROPIC_BASE_URL="$ANTHROPIC_BASE_URL"
export ROCR_VISIBLE_DEVICES=0,1,2,3 TOKENIZERS_PARALLELISM=false
export GEAK_ALLOW_HARDCODED_PATHS=1
export GEAK_SKIP_SANITIZER=1
REPO=/tmp/geak-work2/mxfp4_dynquant
TESTCMD="python3 scripts/task_runner.py compile && python3 scripts/task_runner.py correctness && python3 scripts/task_runner.py performance"
geak --config /tmp/geak-work/geak_local.yaml \
  --repo "$REPO" --kernel-url "$REPO/kernel.py" \
  --test-command "$TESTCMD" --task /tmp/geak-work2/task.txt \
  --num-parallel 4 --gpu-ids 0,1,2,3 --mode full --target kernel --debug --yolo \
  -o /tmp/geak-work2/geak_run 2>&1
