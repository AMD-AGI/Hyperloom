#!/usr/bin/env bash
# Serve with EXACT ml-perf tp1_mxfp4 knobs. Args: GPU PORT EXTRA_ENV SILU(0/1)
GPU=$1; PORT=$2; ENVS="${3:-}"; SILU="${4:-0}"
MODEL=/tmp/q3vl-mxfp4
LOG=/tmp/q3vl-run/tp1_g${GPU}_p${PORT}.log
export ROCR_VISIBLE_DEVICES=$GPU HIP_VISIBLE_DEVICES=0
export AITER_ONLINE_TUNE=0 VLLM_ROCM_USE_AITER=1 VLLM_ROCM_USE_AITER_MOE=1 VLLM_ROCM_USE_AITER_LINEAR=1
export VLLM_ROCM_USE_AITER_RMSNORM=1 VLLM_ROCM_USE_AITER_MHA=1 AITER_USE_CK_MOE_SORTING=1
export HOME=/tmp/hfhome HF_HOME=/tmp/hf_cache
for kv in $ENVS; do export "$kv"; done
if [ "$SILU" = "1" ]; then
  CC='{"mode":3,"cudagraph_mode":"FULL_AND_PIECEWISE","custom_ops":["+rms_norm","+quant_fp8","+silu_and_mul"]}'
else
  CC='{"mode":3,"cudagraph_mode":"FULL_AND_PIECEWISE","custom_ops":["+rms_norm","+quant_fp8"]}'
fi
nohup vllm serve "$MODEL" --port "$PORT" \
  --tensor-parallel-size 1 --quantization quark --max-model-len 32768 \
  --max-num-batched-tokens 32768 --max-num-seqs 2048 --gpu-memory-utilization 0.90 \
  --kv-cache-dtype fp8_e4m3 --no-enable-prefix-caching --enable-chunked-prefill --async-scheduling \
  --mm-encoder-tp-mode data --trust-remote-code \
  --compilation-config "$CC" --attention-backend ROCM_AITER_UNIFIED_ATTN > "$LOG" 2>&1 &
echo "g$GPU p$PORT pid=$! silu=$SILU envs=[$ENVS]"
